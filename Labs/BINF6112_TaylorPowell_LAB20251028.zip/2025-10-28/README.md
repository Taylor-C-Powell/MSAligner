Taylor C. Powell

This Project demonstrates 2 functionalities:
    1. Finding the most prevelant nucleotide in a sequence along with its corresponding numerical count
    2. Converting a nucleotide sequence into an amino acid sequence